package com.example.reto.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class LiquidacionService {

    // Lee los valores del archivo application.properties
    @Value("${simulador.tasa-iva:0.19}")
    private double tasaIva;

    @Value("${simulador.descuento-institucional:0.05}")
    private double descuentoInstitucional;

    public void ejecutarSimulacion(double tarifaBase) {
        double montoDescuento = tarifaBase * descuentoInstitucional;
        double subtotal = tarifaBase - montoDescuento;
        double montoIva = subtotal * tasaIva;
        double totalLiquidar = subtotal + montoIva;

        System.out.println("=========================================");
        System.out.println("   SIMULADOR DE LIQUIDACIÓN INSTITUCIONAL ");
        System.out.println("=========================================");
        System.out.println("Tarifa Base Inicial:       $" + tarifaBase);
        System.out.println("Descuento (" + (descuentoInstitucional * 100) + "%):       -$" + montoDescuento);
        System.out.println("Subtotal:                  $" + subtotal);
        System.out.println("IVA (" + (tasaIva * 100) + "%):                 +$" + montoIva);
        System.out.println("-----------------------------------------");
        System.out.println("TOTAL A LIQUIDAR:          $" + totalLiquidar);
        System.out.println("=========================================\n");
    }
}