package com.example.reto.runner;

import com.example.reto.service.LiquidacionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class SimuladorConsoleRunner implements CommandLineRunner {

    // Inyección de dependencia sin utilizar 'new'
    @Autowired
    private LiquidacionService liquidacionService;

    @Override
    public void run(String... args) throws Exception {
        System.out.println("\n>>> Servicio iniciado: Procesando simulación al arranque...\n");
        
        // Tarifa de prueba $1,000,000
        double tarifaPrueba = 1000000.00;
        liquidacionService.ejecutarSimulacion(tarifaPrueba);
    }
}